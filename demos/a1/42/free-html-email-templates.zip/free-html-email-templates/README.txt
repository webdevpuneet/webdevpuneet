Free HTML email templates from https://webdevpuneet.com/email-templates/

Each folder has the email HTML and its plain-text version. Merge tags use {{first_name}} style tokens.
Edit any template online (logo, colours, fonts, sections, merge tags for Mailchimp, Klaviyo, HubSpot or Brevo):
https://webdevpuneet.com/email-templates/
